import webbrowser
from time import sleep
import os

sleep(1)
print("Yooolpy presents : ")
sleep(1)
print("""

 ██▓███   ██▓  ▄████  ███▄    █  ▒█████   █    ██   █████▒▄▄▄     ▄▄▄█████▓ ▒█████   ██▀███  
▓██░  ██▒▓██▒ ██▒ ▀█▒ ██ ▀█   █ ▒██▒  ██▒ ██  ▓██▒▓██   ▒▒████▄   ▓  ██▒ ▓▒▒██▒  ██▒▓██ ▒ ██▒
▓██░ ██▓▒▒██▒▒██░▄▄▄░▓██  ▀█ ██▒▒██░  ██▒▓██  ▒██░▒████ ░▒██  ▀█▄ ▒ ▓██░ ▒░▒██░  ██▒▓██ ░▄█ ▒
▒██▄█▓▒ ▒░██░░▓█  ██▓▓██▒  ▐▌██▒▒██   ██░▓▓█  ░██░░▓█▒  ░░██▄▄▄▄██░ ▓██▓ ░ ▒██   ██░▒██▀▀█▄  
▒██▒ ░  ░░██░░▒▓███▀▒▒██░   ▓██░░ ████▓▒░▒▒█████▓ ░▒█░    ▓█   ▓██▒ ▒██▒ ░ ░ ████▓▒░░██▓ ▒██▒
▒▓▒░ ░  ░░▓   ░▒   ▒ ░ ▒░   ▒ ▒ ░ ▒░▒░▒░ ░▒▓▒ ▒ ▒  ▒ ░    ▒▒   ▓▒█░ ▒ ░░   ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░
░▒ ░      ▒ ░  ░   ░ ░ ░░   ░ ▒░  ░ ▒ ▒░ ░░▒░ ░ ░  ░       ▒   ▒▒ ░   ░      ░ ▒ ▒░   ░▒ ░ ▒░
░░        ▒ ░░ ░   ░    ░   ░ ░ ░ ░ ░ ▒   ░░░ ░ ░  ░ ░     ░   ▒    ░      ░ ░ ░ ▒    ░░   ░ 
          ░        ░          ░     ░ ░     ░                  ░  ░            ░ ░     ░     
                                                                                             

""")

print("Version 1.0...")
sleep(3)
running = True
categories = ["hetero", "gay", "lesbian", "bdsm", "gay animation"]
print(f"Please choose an available category : {categories} ")
question = input("What do you want to see ? ")
while running:
    if question == "hetero":
        print("Ok...")
        print("Launching page...")
        sleep(3)
        webbrowser.open("http://fr.pornhub.com/")
        running = False
    elif question == "gay":
        print("Ok...")
        print("Launching page...")
        sleep(3)
        webbrowser.open("https://fr.pornhub.com/gayporn")
        running = False
    elif question == "lesbian":
        print("Ok...")
        print("Launching page...")
        sleep(3)
        webbrowser.open("https://fr.pornhub.com/video?c=27")
        running = False
    elif question == "bdsm":
        print("Ok...")
        print("Launching page...")
        sleep(3)
        webbrowser.open("https://fr.pornhub.com/video/search?search=bdsm")
        running = False
    elif question == "gay animation":
        print("Ok...")
        print("Launching page...")
        sleep(3)
        webbrowser.open("https://fr.pornhub.com/model/maruten20")
        running = False
    else:
        question = input("Coming soon ! (The category cannot be found...) Please choose another : ")

sleep(10)
print("""




""")
print("DON'T FORGET TO CLEAR YOUR HISTORY !!! ")
sleep(2)
print("Please type 'exit' to close this window...")
exit()