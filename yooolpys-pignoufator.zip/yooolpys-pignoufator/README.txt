		*************************************
		   PIGNOUFATOR          by Yooolpy
		*************************************
		
 * This is the beta version 1.0 released on Sept, 2022 ! *
 
 * Thanks for downloading ! <3 *
 
 
 
 * Python is required to use this software, please install it with the video link below. *
        -> https://www.youtube.com/watch?v=IS117_uXZKE
		
		
		
 * Installation instructions : *
    - Extract the content from this zip folder to your Desktop ('Extract all' option) -> (C:/users/'your session name'/Desktop)
    - You should have a simple folder that appared on your Desktop
    - /Windows + R/ then type 'cmd', a black window should be showing up                  *
    - type 'cd' with a space and slide the folder just after the space, and "enter" it    *
    - type 'python pignoufator.py', "enter" it.                                           *
		
		*** ENJOY ! ***
		

    -> Note: You'll have to repeat this last 3 steps before each use. (noted with *)
	 
	 
	 
	
   